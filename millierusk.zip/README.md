# millierusk_bot
A Advance CC Checker Bot Based On Python

## To Start
-`edit config.yml`
install requirements.txt - `pip install -r requirements.txt`
- `python -m mills` - if Windows
- `sudo bash start.sh`- if linux
- `python3 -m mills`
